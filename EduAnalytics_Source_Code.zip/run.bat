@echo off
title EduAnalytics - Starting Application
echo ========================================================
echo   EduAnalytics - Academic Performance & Analytics System
echo ========================================================
echo.
echo [1/2] Checking and installing required packages...
pip install -r requirements.txt
echo.
echo [2/2] Launching Streamlit web application on http://localhost:8501 ...
start http://localhost:8501
streamlit run app.py
pause
