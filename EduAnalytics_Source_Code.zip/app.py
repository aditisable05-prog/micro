"""
Automated Academic Performance Analytics and Digital Report Card Generation System
Branded as "EduAnalytics"
Tech Stack: Python, Streamlit, SQLite, Pandas, Plotly
"""

import os
import sqlite3
from datetime import datetime
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ==============================================================================
# 1. PAGE CONFIGURATION & CUSTOM THEME (Clean Light-Gray Canvas #F4F7FB)
# ==============================================================================
st.set_page_config(
    page_title="EduAnalytics - Academic Performance & Digital Report Card System",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS matching exact specifications
st.markdown("""
<style>
    /* Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    /* Global canvas & typography */
    html, body, [class*="css"], .stApp {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        background-color: #F4F7FB !important;
        color: #1E293B;
    }

    /* Main block container padding */
    .block-container {
        padding-top: 1.8rem;
        padding-bottom: 2.5rem;
        padding-left: 2.2rem;
        padding-right: 2.2rem;
        max-width: 1380px;
    }

    /* Top banner / header */
    .edu-header-container {
        background: linear-gradient(135deg, #1E3A8A 0%, #2563EB 100%);
        border-radius: 14px;
        padding: 22px 28px;
        color: #FFFFFF;
        margin-bottom: 24px;
        box-shadow: 0 4px 16px rgba(37, 99, 235, 0.15);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .edu-header-title {
        font-size: 22px;
        font-weight: 800;
        letter-spacing: -0.3px;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .edu-header-sub {
        font-size: 13px;
        color: #BFDBFE;
        margin-top: 4px;
        font-weight: 500;
    }
    .edu-header-pill {
        background: rgba(255, 255, 255, 0.16);
        border: 1px solid rgba(255, 255, 255, 0.28);
        border-radius: 999px;
        padding: 6px 14px;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.3px;
    }

    /* Card styling */
    .edu-card {
        background-color: #FFFFFF;
        border-radius: 14px;
        border: 1px solid #EDF2F7;
        box-shadow: 0 4px 14px rgba(15, 23, 42, 0.035);
        padding: 22px 24px;
        margin-bottom: 22px;
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .edu-card:hover {
        box-shadow: 0 6px 20px rgba(15, 23, 42, 0.05);
    }
    .edu-card-title {
        font-size: 16px;
        font-weight: 700;
        color: #0F172A;
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .edu-card-subtitle {
        font-size: 12.5px;
        color: #64748B;
        margin-bottom: 16px;
        font-weight: 500;
    }

    /* KPI Metrics Card */
    .kpi-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 18px;
        margin-bottom: 24px;
    }
    @media (max-width: 900px) {
        .kpi-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    .kpi-card {
        background-color: #FFFFFF;
        border-radius: 14px;
        border: 1px solid #EDF2F7;
        box-shadow: 0 4px 14px rgba(15, 23, 42, 0.03);
        padding: 18px 20px;
        display: flex;
        align-items: center;
        gap: 16px;
    }
    .kpi-icon-badge {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        flex-shrink: 0;
    }
    .badge-blue   { background-color: #EFF6FF; color: #2563EB; }
    .badge-purple { background-color: #F5F3FF; color: #7C3AED; }
    .badge-green  { background-color: #ECFDF5; color: #059669; }
    .badge-amber  { background-color: #FFFBEB; color: #D97706; }

    .kpi-label {
        font-size: 12.5px;
        font-weight: 600;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 3px;
    }
    .kpi-value {
        font-size: 27px;
        font-weight: 800;
        color: #0F172A;
        line-height: 1.1;
    }
    .kpi-subtext {
        font-size: 11.5px;
        color: #94A3B8;
        margin-top: 3px;
        font-weight: 500;
    }

    /* Clean Styled Table */
    .edu-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        font-size: 13.5px;
        text-align: left;
    }
    .edu-table th {
        background-color: #F8FAFC;
        color: #475569;
        font-weight: 700;
        padding: 12px 16px;
        border-bottom: 2px solid #E2E8F0;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .edu-table td {
        padding: 13px 16px;
        border-bottom: 1px solid #F1F5F9;
        color: #1E293B;
        vertical-align: middle;
    }
    .edu-table tr:hover td {
        background-color: #F8FAFC;
    }

    /* Colored Pill Badges */
    .badge-pill {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 11.5px;
        font-weight: 700;
        text-align: center;
        letter-spacing: 0.3px;
    }
    .badge-grade-aaa { background-color: #DCFCE7; color: #15803D; border: 1px solid #86EFAC; }
    .badge-grade-aa  { background-color: #D1FAE5; color: #047857; border: 1px solid #6EE7B7; }
    .badge-grade-a   { background-color: #E0F2FE; color: #0369A1; border: 1px solid #7DD3FC; }
    .badge-grade-b   { background-color: #DBEAFE; color: #1D4ED8; border: 1px solid #93C5FD; }
    .badge-grade-c   { background-color: #FEF3C7; color: #B45309; border: 1px solid #FDE68A; }
    .badge-grade-d   { background-color: #FFEDD5; color: #C2410C; border: 1px solid #FDBA74; }
    .badge-grade-f   { background-color: #FEE2E2; color: #B91C1C; border: 1px solid #FCA5A5; }

    .badge-status-pass    { background-color: #DEF7EC; color: #03543F; font-weight: 700; }
    .badge-status-fail    { background-color: #FDE8E8; color: #9B1C1C; font-weight: 700; }
    .badge-status-pending { background-color: #FEF08A; color: #854D0E; font-weight: 700; }

    /* Sidebar Navigation Enhancement */
    [data-testid="stSidebar"] {
        background-color: #FFFFFF !important;
        border-right: 1px solid #EDF2F7;
    }
    [data-testid="stSidebar"] .block-container {
        padding: 1.5rem 1rem !important;
    }
    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 12px 18px 12px;
        border-bottom: 1px solid #F1F5F9;
        margin-bottom: 18px;
    }
    .sidebar-brand-icon {
        font-size: 30px;
        line-height: 1;
    }
    .sidebar-brand-name {
        font-size: 21px;
        font-weight: 800;
        color: #0F172A;
        letter-spacing: -0.3px;
    }
    .sidebar-brand-sub {
        font-size: 11px;
        color: #64748B;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.6px;
    }

    /* Form & Input Labels */
    label[data-testid="stWidgetLabel"] p,
    label[data-testid="stWidgetLabel"] span,
    .stSelectbox label p,
    .stTextInput label p,
    .stNumberInput label p {
        color: #0F172A !important;
        font-weight: 700 !important;
        font-size: 13.5px !important;
    }
    div[data-baseweb="select"] > div {
        background-color: #FFFFFF !important;
        border-color: #CBD5E1 !important;
        border-radius: 8px !important;
    }
    div[data-baseweb="select"] span {
        color: #0F172A !important;
        font-weight: 600 !important;
    }
    div[data-baseweb="input"] input {
        color: #0F172A !important;
        font-weight: 600 !important;
        background-color: #FFFFFF !important;
    }
    [data-testid="stAlert"] {
        border-radius: 10px !important;
    }

    /* Active navigation pill styling in sidebar radio */
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-testid="stWidgetLabel"] {
        display: none !important;
        height: 0px !important;
        padding: 0px !important;
        margin: 0px !important;
        border: none !important;
    }
    [data-testid="stSidebar"] [data-testid="stRadio"] > div {
        gap: 8px !important;
    }
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"] {
        display: flex !important;
        align-items: center !important;
        background-color: #F8FAFC !important;
        border: 1px solid #E2E8F0 !important;
        border-radius: 10px !important;
        padding: 10px 16px !important;
        margin: 2px 0 !important;
        cursor: pointer !important;
        transition: all 0.18s ease-in-out;
    }
    /* Hide default radio circle so each item is a pure pill */
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"] > div:first-child {
        display: none !important;
    }
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"] p,
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"] span,
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"] div {
        color: #1E293B !important;
        font-size: 14.5px !important;
        font-weight: 600 !important;
        margin: 0 !important;
    }
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"]:hover {
        background-color: #F1F5F9 !important;
        border-color: #CBD5E1 !important;
    }
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"]:has(input:checked) {
        background-color: #2563EB !important;
        border-color: #2563EB !important;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.28) !important;
    }
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"]:has(input:checked) p,
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"]:has(input:checked) span,
    [data-testid="stSidebar"] [data-testid="stRadio"] label[data-baseweb="radio"]:has(input:checked) div {
        color: #FFFFFF !important;
        font-weight: 700 !important;
    }

    /* Buttons */
    .stButton > button {
        border-radius: 10px;
        font-weight: 600;
        padding: 0.5rem 1.25rem;
        transition: all 0.18s ease;
    }
    .stButton > button[kind="primary"] {
        background-color: #2563EB !important;
        border-color: #2563EB !important;
        box-shadow: 0 2px 6px rgba(37, 99, 235, 0.25);
    }
    .stButton > button[kind="primary"]:hover {
        background-color: #1D4ED8 !important;
    }

    /* Institution Report Card styling */
    .report-card-sheet {
        background-color: #FFFFFF;
        border: 2px solid #CBD5E1;
        border-radius: 12px;
        padding: 36px 42px;
        box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
        max-width: 900px;
        margin: 0 auto 30px auto;
        color: #0F172A;
    }
    .report-header-inst {
        text-align: center;
        border-bottom: 2px solid #0F172A;
        padding-bottom: 16px;
        margin-bottom: 24px;
    }
    .report-header-inst h2 {
        font-size: 20px;
        font-weight: 800;
        margin: 0 0 6px 0;
        letter-spacing: 0.5px;
        color: #1E3A8A;
    }
    .report-header-inst h4 {
        font-size: 13px;
        font-weight: 600;
        color: #475569;
        margin: 0 0 8px 0;
    }
    .report-header-inst .badge-doc {
        display: inline-block;
        background-color: #0F172A;
        color: #FFFFFF;
        padding: 4px 16px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 1px;
    }
    .report-meta-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        row-gap: 10px;
        column-gap: 24px;
        background-color: #F8FAFC;
        padding: 16px 20px;
        border-radius: 8px;
        border: 1px solid #E2E8F0;
        margin-bottom: 24px;
        font-size: 13.5px;
    }
    .report-meta-row strong {
        color: #475569;
        display: inline-block;
        width: 140px;
    }
    .report-summary-box {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #F8FAFC;
        border: 1.5px solid #CBD5E1;
        border-radius: 8px;
        padding: 18px 24px;
        margin-top: 24px;
    }
</style>
""", unsafe_allow_html=True)

# ==============================================================================
# 2. DATABASE INITIALIZATION & PRE-LOADED EXPO DATA (SQLite)
# ==============================================================================
DB_PATH = os.path.join(os.path.dirname(__file__), "eduanalytics.db")

def get_db_connection():
    """Connects to SQLite with Foreign Keys enabled."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Creates students, subjects, and marks tables and seeds Expo demo data."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Exact Schema as specified
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        roll_number TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        class_name TEXT NOT NULL,
        semester TEXT NOT NULL,
        academic_year TEXT NOT NULL
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_name TEXT NOT NULL UNIQUE,
        maximum_marks REAL NOT NULL CHECK(maximum_marks > 0)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS marks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        marks_obtained REAL NOT NULL CHECK(marks_obtained >= 0),
        UNIQUE(student_id, subject_id),
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
    );
    """)
    conn.commit()

    # Check if empty to seed Pre-loaded Expo Demo Data
    cursor.execute("SELECT COUNT(*) FROM students")
    student_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM subjects")
    subject_count = cursor.fetchone()[0]

    if student_count == 0 and subject_count == 0:
        # 1. Seed 5 Starter Subjects (100 Max Marks each)
        starter_subjects = [
            ("Maths", 100.0),
            ("Science", 100.0),
            ("English", 100.0),
            ("Social", 100.0),
            ("Computer", 100.0)
        ]
        cursor.executemany("INSERT INTO subjects (subject_name, maximum_marks) VALUES (?, ?);", starter_subjects)

        # 2. Seed 5 Starter Students (from Project Milestones & Exhibition Poster)
        starter_students = [
            ("101", "Aarav Sharma", "B.Tech AI/CSE", "Semester I", "2026-27"),
            ("102", "Riya Patel", "B.Tech AI/CSE", "Semester I", "2026-27"),
            ("103", "Kunal Verma", "B.Tech AI/CSE", "Semester I", "2026-27"),
            ("BTAI2601004", "Aditi Sable", "B.Tech AI/CSE", "Semester I", "2026-27"),
            ("BTAI2601066", "Lavi Sharma", "B.Tech AI/CSE", "Semester I", "2026-27"),
        ]
        cursor.executemany("""
        INSERT INTO students (roll_number, name, class_name, semester, academic_year)
        VALUES (?, ?, ?, ?, ?);
        """, starter_students)

        # Retrieve mapped IDs
        cursor.execute("SELECT id, roll_number FROM students")
        student_ids = {row["roll_number"]: row["id"] for row in cursor.fetchall()}

        cursor.execute("SELECT id, subject_name FROM subjects")
        subject_ids = {row["subject_name"]: row["id"] for row in cursor.fetchall()}

        # 3. Seed Complete Marks for all 5 demo students
        demo_marks = [
            # Aarav Sharma: Total 465/500 (93.0% -> AAA)
            (student_ids["101"], subject_ids["Maths"], 95.0),
            (student_ids["101"], subject_ids["Science"], 88.0),
            (student_ids["101"], subject_ids["English"], 92.0),
            (student_ids["101"], subject_ids["Social"], 94.0),
            (student_ids["101"], subject_ids["Computer"], 96.0),

            # Riya Patel: Total 432/500 (86.4% -> AA)
            (student_ids["102"], subject_ids["Maths"], 88.0),
            (student_ids["102"], subject_ids["Science"], 86.0),
            (student_ids["102"], subject_ids["English"], 84.0),
            (student_ids["102"], subject_ids["Social"], 85.0),
            (student_ids["102"], subject_ids["Computer"], 89.0),

            # Kunal Verma: Total 389/500 (77.8% -> A)
            (student_ids["103"], subject_ids["Maths"], 78.0),
            (student_ids["103"], subject_ids["Science"], 72.0),
            (student_ids["103"], subject_ids["English"], 80.0),
            (student_ids["103"], subject_ids["Social"], 75.0),
            (student_ids["103"], subject_ids["Computer"], 84.0),

            # Aditi Sable: Total 455/500 (91.0% -> AAA)
            (student_ids["BTAI2601004"], subject_ids["Maths"], 91.0),
            (student_ids["BTAI2601004"], subject_ids["Science"], 90.0),
            (student_ids["BTAI2601004"], subject_ids["English"], 93.0),
            (student_ids["BTAI2601004"], subject_ids["Social"], 87.0),
            (student_ids["BTAI2601004"], subject_ids["Computer"], 94.0),

            # Lavi Sharma: Total 428/500 (85.6% -> AA)
            (student_ids["BTAI2601066"], subject_ids["Maths"], 85.0),
            (student_ids["BTAI2601066"], subject_ids["Science"], 84.0),
            (student_ids["BTAI2601066"], subject_ids["English"], 88.0),
            (student_ids["BTAI2601066"], subject_ids["Social"], 82.0),
            (student_ids["BTAI2601066"], subject_ids["Computer"], 89.0),
        ]

        cursor.executemany("""
        INSERT INTO marks (student_id, subject_id, marks_obtained)
        VALUES (?, ?, ?);
        """, demo_marks)
        conn.commit()

    conn.close()

init_db()

# ==============================================================================
# 3. CORE CALCULATION & GRADING LOGIC
# ==============================================================================
def calculate_grade(percentage: float) -> str:
    """
    Grading Scale defined in project specification:
    >= 90: AAA
    >= 80: AA
    >= 70: A
    >= 60: B
    >= 50: C
    >= 40: D
    < 40:  F
    """
    if percentage >= 90.0:
        return "AAA"
    elif percentage >= 80.0:
        return "AA"
    elif percentage >= 70.0:
        return "A"
    elif percentage >= 60.0:
        return "B"
    elif percentage >= 50.0:
        return "C"
    elif percentage >= 40.0:
        return "D"
    else:
        return "F"

def get_grade_badge_html(grade: str) -> str:
    """Returns styled HTML pill badge for grades."""
    mapping = {
        "AAA": "badge-grade-aaa",
        "AA":  "badge-grade-aa",
        "A":   "badge-grade-a",
        "B":   "badge-grade-b",
        "C":   "badge-grade-c",
        "D":   "badge-grade-d",
        "F":   "badge-grade-f",
    }
    cls = mapping.get(grade, "badge-grade-f")
    return f'<span class="badge-pill {cls}">{grade}</span>'

def get_status_badge_html(status: str) -> str:
    """Returns styled HTML pill badge for academic result status."""
    if status == "Pass":
        return '<span class="badge-pill badge-status-pass">✓ Pass</span>'
    elif status == "Fail":
        return '<span class="badge-pill badge-status-fail">✕ Fail</span>'
    else:
        return '<span class="badge-pill badge-status-pending">⏳ Pending marks</span>'

def render_clean_html(html_str: str):
    """Strips leading whitespace from every line so markdown does not interpret HTML tags as code blocks."""
    cleaned = "\n".join(line.strip() for line in html_str.strip().splitlines())
    return st.markdown(cleaned, unsafe_allow_html=True)

def fetch_all_student_results():
    """
    Retrieves all students, computes aggregate scores, percentages, grades,
    and completion status. Missing marks yield 'Pending marks'.
    """
    conn = get_db_connection()
    students_df = pd.read_sql_query("SELECT * FROM students ORDER BY id ASC;", conn)
    subjects_df = pd.read_sql_query("SELECT * FROM subjects ORDER BY id ASC;", conn)
    marks_df = pd.read_sql_query("SELECT * FROM marks;", conn)
    conn.close()

    total_subjects_count = len(subjects_df)
    total_possible_max_marks = float(subjects_df["maximum_marks"].sum()) if total_subjects_count > 0 else 0.0

    results = []
    for _, student in students_df.iterrows():
        s_id = student["id"]
        s_marks = marks_df[marks_df["student_id"] == s_id]
        entered_count = len(s_marks)
        
        # Check completeness
        is_complete = (total_subjects_count > 0) and (entered_count == total_subjects_count)
        
        obtained_sum = float(s_marks["marks_obtained"].sum()) if entered_count > 0 else 0.0
        
        if is_complete:
            pct = (obtained_sum / total_possible_max_marks * 100.0) if total_possible_max_marks > 0 else 0.0
            grade = calculate_grade(pct)
            status = "Pass" if pct >= 40.0 else "Fail"
        else:
            pct = (obtained_sum / total_possible_max_marks * 100.0) if total_possible_max_marks > 0 else 0.0
            grade = "Pending"
            status = "Pending marks"

        results.append({
            "id": s_id,
            "roll_number": student["roll_number"],
            "name": student["name"],
            "class_name": student["class_name"],
            "semester": student["semester"],
            "academic_year": student["academic_year"],
            "entered_subjects": entered_count,
            "total_subjects": total_subjects_count,
            "is_complete": is_complete,
            "total_marks": obtained_sum,
            "max_marks": total_possible_max_marks,
            "percentage": pct,
            "grade": grade,
            "status": status
        })

    return pd.DataFrame(results), subjects_df, marks_df

# ==============================================================================
# 4. SIDEBAR NAVIGATION
# ==============================================================================
with st.sidebar:
    st.markdown("""
    <div class="sidebar-brand">
        <div class="sidebar-brand-icon">🎓</div>
        <div>
            <div class="sidebar-brand-name">EduAnalytics</div>
            <div class="sidebar-brand-sub">Academic Performance</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    nav_selection = st.radio(
        label="Navigation Menu",
        options=[
            "Dashboard",
            "Students",
            "Subjects",
            "Marks Entry",
            "Reports",
            "Analytics"
        ],
        index=0,
        label_visibility="collapsed"
    )

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("""
    <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:10px; padding:14px; font-size:12px; color:#64748B;">
        <strong style="color:#1E293B; display:block; margin-bottom:4px;">Madhav Institute of Technology & Science</strong>
        MITS Gwalior • B.Tech AI / CSE<br>
        <span style="display:inline-block; margin-top:6px; color:#2563EB; font-weight:600;">Active Session: 2026–27</span>
    </div>
    """, unsafe_allow_html=True)

# Fetch latest calculated data
results_df, subjects_df, raw_marks_df = fetch_all_student_results()

# ==============================================================================
# VIEW 1: DASHBOARD
# ==============================================================================
if nav_selection == "Dashboard":
    st.markdown("""
    <div class="edu-header-container">
        <div>
            <div class="edu-header-title">🎓 EduAnalytics Dashboard</div>
            <div class="edu-header-sub">Automated Academic Performance Analytics and Institutional Assessment Overview</div>
        </div>
        <div class="edu-header-pill">Session 2026–27 • Semester I</div>
    </div>
    """, unsafe_allow_html=True)

    # Calculate KPIs
    total_students = len(results_df)
    total_subjects = len(subjects_df)
    
    # Only completed students count toward pass rate and class average
    completed_df = results_df[results_df["is_complete"] == True]
    completed_count = len(completed_df)
    
    if completed_count > 0:
        pass_count = len(completed_df[completed_df["status"] == "Pass"])
        pass_rate = (pass_count / completed_count) * 100.0
        avg_score = completed_df["percentage"].mean()
    else:
        pass_rate = 0.0
        avg_score = 0.0

    # TOP ROW: 4 KPI CARDS WITH COLORED ICON BADGES
    st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-card">
            <div class="kpi-icon-badge badge-blue">👥</div>
            <div>
                <div class="kpi-label">Total Students</div>
                <div class="kpi-value">{total_students}</div>
                <div class="kpi-subtext">Active Enrolled Learners</div>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon-badge badge-purple">📚</div>
            <div>
                <div class="kpi-label">Subjects</div>
                <div class="kpi-value">{total_subjects}</div>
                <div class="kpi-subtext">Curriculum Courses</div>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon-badge badge-green">📈</div>
            <div>
                <div class="kpi-label">Pass Rate</div>
                <div class="kpi-value">{pass_rate:.1f}%</div>
                <div class="kpi-subtext">Passing Benchmark (≥40%)</div>
            </div>
        </div>
        <div class="kpi-card">
            <div class="kpi-icon-badge badge-amber">⭐</div>
            <div>
                <div class="kpi-label">Average Score</div>
                <div class="kpi-value">{avg_score:.1f}%</div>
                <div class="kpi-subtext">Class Mean Evaluation</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # MIDDLE ROW: 2 SIDE-BY-SIDE CARDS (Class Performance & Grade Distribution)
    col_chart_left, col_chart_right = st.columns(2)

    with col_chart_left:
        st.markdown("""
        <div class="edu-card">
            <div class="edu-card-title">📊 Class Performance</div>
            <div class="edu-card-subtitle">Subject-wise average percentage across all enrolled students</div>
        """, unsafe_allow_html=True)

        if not subjects_df.empty and not raw_marks_df.empty:
            # Compute subject-wise average percentage
            subj_perf = []
            for _, s_row in subjects_df.iterrows():
                sub_id = s_row["id"]
                sub_name = s_row["subject_name"]
                sub_max = s_row["maximum_marks"]
                sub_marks = raw_marks_df[raw_marks_df["subject_id"] == sub_id]["marks_obtained"]
                if not sub_marks.empty:
                    avg_pct = (sub_marks.mean() / sub_max) * 100.0
                else:
                    avg_pct = 0.0
                subj_perf.append({"Subject": sub_name, "Average Percentage": round(avg_pct, 1)})

            perf_df = pd.DataFrame(subj_perf)

            # Design multi-colored vertical bar chart: blue, green, amber, red, purple
            palette = ["#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#EC4899", "#06B6D4"]
            bar_colors = [palette[i % len(palette)] for i in range(len(perf_df))]

            fig_bar = go.Figure(data=[
                go.Bar(
                    x=perf_df["Subject"].tolist(),
                    y=perf_df["Average Percentage"].tolist(),
                    marker=dict(
                        color=bar_colors,
                        line=dict(width=0)
                    ),
                    text=[f"{val:.1f}%" for val in perf_df["Average Percentage"]],
                    textposition="outside",
                    hovertemplate="<b>%{x}</b><br>Average: %{y:.1f}%<extra></extra>",
                    cliponaxis=False
                )
            ])

            fig_bar.update_layout(
                yaxis=dict(
                    range=[0, 105],
                    title=dict(text="Average Score (%)", font=dict(size=13, color="#475569")),
                    gridcolor="#F1F5F9",
                    zeroline=False,
                    tickfont=dict(size=12, color="#64748B")
                ),
                xaxis=dict(
                    tickfont=dict(size=12, color="#334155"),
                    showgrid=False
                ),
                plot_bgcolor="rgba(0,0,0,0)",
                paper_bgcolor="rgba(0,0,0,0)",
                margin=dict(l=20, r=20, t=25, b=20),
                height=320
            )

            st.plotly_chart(fig_bar, use_container_width=True, config={"displayModeBar": False})
        else:
            st.info("No subject marks data currently available to generate performance chart.")

        st.markdown("</div>", unsafe_allow_html=True)

    with col_chart_right:
        st.markdown("""
        <div class="edu-card">
            <div class="edu-card-title">🍩 Grade Distribution</div>
            <div class="edu-card-subtitle">Percentage breakdown of grades for completed student reports</div>
        """, unsafe_allow_html=True)

        if completed_count > 0:
            grade_counts = completed_df["grade"].value_counts().reset_index()
            grade_counts.columns = ["Grade", "Count"]

            # Grade color mapping
            color_map = {
                "AAA": "#10B981",  # Emerald Green
                "AA":  "#34D399",  # Mint Green
                "A":   "#6EE7B7",  # Light Green
                "B":   "#3B82F6",  # Royal Blue
                "C":   "#F59E0B",  # Amber
                "D":   "#F97316",  # Orange
                "F":   "#EF4444"   # Red
            }
            pie_colors = [color_map.get(g, "#94A3B8") for g in grade_counts["Grade"]]

            fig_donut = go.Figure(data=[
                go.Pie(
                    labels=grade_counts["Grade"].tolist(),
                    values=grade_counts["Count"].tolist(),
                    hole=0.68,
                    marker=dict(colors=pie_colors),
                    textinfo="percent",
                    hoverinfo="label+value+percent",
                    direction="clockwise",
                    sort=False
                )
            ])

            # Center text annotation showing completed count
            fig_donut.update_layout(
                annotations=[
                    dict(
                        text=f"<b style='font-size:26px;color:#0F172A'>{completed_count}</b><br><span style='font-size:12px;color:#64748B;font-weight:600'>Students</span>",
                        x=0.5, y=0.5,
                        font_size=14,
                        showarrow=False
                    )
                ],
                legend=dict(
                    orientation="v",
                    x=1.02,
                    y=0.5,
                    font=dict(size=12, color="#475569")
                ),
                plot_bgcolor="rgba(0,0,0,0)",
                paper_bgcolor="rgba(0,0,0,0)",
                margin=dict(l=10, r=10, t=20, b=20),
                height=320
            )

            st.plotly_chart(fig_donut, use_container_width=True, config={"displayModeBar": False})
        else:
            st.info("Grade distribution will appear as soon as student marks are finalized.")

        st.markdown("</div>", unsafe_allow_html=True)

    # BOTTOM ROW: RECENT STUDENTS CARD
    if not results_df.empty:
        table_html = """
        <div class="edu-card">
            <div class="edu-card-title">📋 Recent Students & Academic Standing</div>
            <div class="edu-card-subtitle">Institutional roster with verified marks, aggregated percentage, and grading results</div>
            <div style="overflow-x:auto;">
            <table class="edu-table">
                <thead>
                    <tr>
                        <th>Roll No</th>
                        <th>Name</th>
                        <th>Class / Branch</th>
                        <th>Total Marks</th>
                        <th>Percentage</th>
                        <th>Grade</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
        """
        for _, r in results_df.iterrows():
            total_str = f"{r['total_marks']:.0f}/{r['max_marks']:.0f}" if r['is_complete'] else f"{r['total_marks']:.0f}/{r['max_marks']:.0f} (Incomplete)"
            pct_str = f"{r['percentage']:.1f}%" if r['is_complete'] else f"{r['percentage']:.1f}%*"
            grade_pill = get_grade_badge_html(r['grade']) if r['is_complete'] else '<span class="badge-pill" style="background:#F1F5F9;color:#64748B;">N/A</span>'
            status_pill = get_status_badge_html(r['status'])

            table_html += f"""
                    <tr>
                        <td><strong>{r['roll_number']}</strong></td>
                        <td>{r['name']}</td>
                        <td>{r['class_name']} ({r['semester']})</td>
                        <td>{total_str}</td>
                        <td><strong>{pct_str}</strong></td>
                        <td>{grade_pill}</td>
                        <td>{status_pill}</td>
                    </tr>
            """
        table_html += """
                </tbody>
            </table>
            </div>
        </div>
        """
        render_clean_html(table_html)
    else:
        st.info("No enrolled students found. Use the 'Students' view to add new candidates.")

# ==============================================================================
# VIEW 2: STUDENTS MANAGEMENT
# ==============================================================================
elif nav_selection == "Students":
    st.markdown("""
    <div class="edu-header-container">
        <div>
            <div class="edu-header-title">👥 Student Management</div>
            <div class="edu-header-sub">Enroll new candidates, manage student directory, and view academic profiles</div>
        </div>
        <div class="edu-header-pill">Directory Management</div>
    </div>
    """, unsafe_allow_html=True)

    col_add, col_list = st.columns([1, 2])

    with col_add:
        st.markdown("""
        <div class="edu-card">
            <div class="edu-card-title">➕ Enroll New Student</div>
            <div class="edu-card-subtitle">Fill in student academic credentials</div>
        """, unsafe_allow_html=True)

        with st.form("add_student_form", clear_on_submit=True):
            f_roll = st.text_input("Roll Number *", placeholder="e.g. 104 or BTAI2601070")
            f_name = st.text_input("Full Name *", placeholder="e.g. Divya Agarwal")
            f_class = st.text_input("Branch / Class *", value="B.Tech AI/CSE")
            f_sem = st.selectbox("Semester *", ["Semester I", "Semester II", "Semester III", "Semester IV", "Semester V", "Semester VI", "Semester VII", "Semester VIII"])
            f_year = st.text_input("Academic Year *", value="2026-27")

            submitted = st.form_submit_button("Enroll Student", type="primary", use_container_width=True)
            if submitted:
                # Validation
                if not f_roll.strip() or not f_name.strip() or not f_class.strip() or not f_year.strip():
                    st.error("⚠️ All fields are mandatory. Please provide complete student credentials.")
                else:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    try:
                        cursor.execute("""
                        INSERT INTO students (roll_number, name, class_name, semester, academic_year)
                        VALUES (?, ?, ?, ?, ?);
                        """, (f_roll.strip(), f_name.strip(), f_class.strip(), f_sem, f_year.strip()))
                        conn.commit()
                        st.success(f"✅ Student '{f_name.strip()}' ({f_roll.strip()}) registered successfully!")
                        st.rerun()
                    except sqlite3.IntegrityError:
                        st.error(f"❌ Error: Roll Number '{f_roll.strip()}' is already registered in the system.")
                    finally:
                        conn.close()

        st.markdown("</div>", unsafe_allow_html=True)

    with col_list:
        st.markdown("""
        <div class="edu-card">
            <div class="edu-card-title">📚 Enrolled Students Directory</div>
            <div class="edu-card-subtitle">Search, filter, and inspect enrolled records</div>
        """, unsafe_allow_html=True)

        search_query = st.text_input("🔍 Search Students by Name or Roll Number", placeholder="Type to search...").strip().lower()

        conn = get_db_connection()
        students_raw = pd.read_sql_query("SELECT * FROM students ORDER BY id ASC;", conn)
        conn.close()

        if not students_raw.empty:
            filtered_students = students_raw
            if search_query:
                filtered_students = students_raw[
                    students_raw["name"].str.lower().str.contains(search_query) |
                    students_raw["roll_number"].str.lower().str.contains(search_query)
                ]

            st.write(f"Showing **{len(filtered_students)}** of **{len(students_raw)}** registered students:")

            # Actionable deletion or view
            for _, s in filtered_students.iterrows():
                col_info, col_del = st.columns([5, 1])
                with col_info:
                    st.markdown(f"""
                    <div style="background:#F8FAFC; border:1px solid #EDF2F7; border-radius:10px; padding:12px 16px; margin-bottom:8px;">
                        <span style="font-size:15px; font-weight:700; color:#0F172A;">{s['name']}</span>
                        <span style="margin-left:8px; background:#EFF6FF; color:#2563EB; font-weight:700; padding:2px 8px; border-radius:6px; font-size:12px;">Roll: {s['roll_number']}</span>
                        <div style="font-size:12px; color:#64748B; margin-top:4px;">
                            Branch: <strong>{s['class_name']}</strong> • {s['semester']} • Session: {s['academic_year']}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                with col_del:
                    if st.button("Delete", key=f"del_stud_{s['id']}", help="Delete student and all associated marks"):
                        del_conn = get_db_connection()
                        del_conn.execute("DELETE FROM students WHERE id = ?;", (s["id"],))
                        del_conn.commit()
                        del_conn.close()
                        st.success(f"Removed student {s['name']}.")
                        st.rerun()
        else:
            st.info("No students currently registered.")

        st.markdown("</div>", unsafe_allow_html=True)

# ==============================================================================
# VIEW 3: SUBJECTS MANAGEMENT
# ==============================================================================
elif nav_selection == "Subjects":
    st.markdown("""
    <div class="edu-header-container">
        <div>
            <div class="edu-header-title">📖 Curriculum & Subject Configuration</div>
            <div class="edu-header-sub">Configure academic subjects, assessment criteria, and maximum achievable marks</div>
        </div>
        <div class="edu-header-pill">Course Catalog</div>
    </div>
    """, unsafe_allow_html=True)

    col_add_sub, col_list_sub = st.columns([1, 2])

    with col_add_sub:
        st.markdown("""
        <div class="edu-card">
            <div class="edu-card-title">➕ Add New Subject</div>
            <div class="edu-card-subtitle">Define course title and maximum score</div>
        """, unsafe_allow_html=True)

        with st.form("add_subject_form", clear_on_submit=True):
            f_sub_name = st.text_input("Subject Name *", placeholder="e.g. Data Structures")
            f_max_marks = st.number_input("Maximum Marks *", min_value=10.0, max_value=500.0, value=100.0, step=10.0)

            sub_submitted = st.form_submit_button("Add Course Subject", type="primary", use_container_width=True)
            if sub_submitted:
                if not f_sub_name.strip():
                    st.error("⚠️ Subject name cannot be empty.")
                elif f_max_marks <= 0:
                    st.error("⚠️ Maximum marks must be greater than zero.")
                else:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    try:
                        cursor.execute("""
                        INSERT INTO subjects (subject_name, maximum_marks)
                        VALUES (?, ?);
                        """, (f_sub_name.strip(), float(f_max_marks)))
                        conn.commit()
                        st.success(f"✅ Subject '{f_sub_name.strip()}' with max marks {f_max_marks} added!")
                        st.rerun()
                    except sqlite3.IntegrityError:
                        st.error(f"❌ Subject '{f_sub_name.strip()}' already exists in the course catalog.")
                    finally:
                        conn.close()

        st.markdown("</div>", unsafe_allow_html=True)

    with col_list_sub:
        st.markdown("""
        <div class="edu-card">
            <div class="edu-card-title">📚 Active Course Subjects</div>
            <div class="edu-card-subtitle">Current registered curriculum subjects and examination weighting</div>
        """, unsafe_allow_html=True)

        conn = get_db_connection()
        subjects_list = pd.read_sql_query("SELECT * FROM subjects ORDER BY id ASC;", conn)
        marks_overview = pd.read_sql_query("SELECT subject_id, COUNT(*) as evaluated_count, AVG(marks_obtained) as avg_marks FROM marks GROUP BY subject_id;", conn)
        conn.close()

        if not subjects_list.empty:
            merged_subs = pd.merge(subjects_list, marks_overview, left_on="id", right_on="subject_id", how="left").fillna(0)

            for _, sub in merged_subs.iterrows():
                col_sinfo, col_sdel = st.columns([5, 1])
                with col_sinfo:
                    st.markdown(f"""
                    <div style="background:#F8FAFC; border:1px solid #EDF2F7; border-radius:10px; padding:12px 18px; margin-bottom:8px;">
                        <span style="font-size:15px; font-weight:700; color:#0F172A;">{sub['subject_name']}</span>
                        <span style="margin-left:10px; background:#F5F3FF; color:#7C3AED; font-weight:700; padding:2px 8px; border-radius:6px; font-size:12px;">Max Marks: {sub['maximum_marks']:.0f}</span>
                        <div style="font-size:12.5px; color:#64748B; margin-top:4px;">
                            Evaluated Students: <strong>{int(sub['evaluated_count'])}</strong> • Class Mean Score: <strong>{sub['avg_marks']:.1f}</strong> / {sub['maximum_marks']:.0f}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                with col_sdel:
                    if st.button("Delete", key=f"del_sub_{sub['id']}", help="Delete subject and all recorded student marks for it"):
                        del_conn = get_db_connection()
                        del_conn.execute("DELETE FROM subjects WHERE id = ?;", (sub["id"],))
                        del_conn.commit()
                        del_conn.close()
                        st.success(f"Removed subject {sub['subject_name']}.")
                        st.rerun()
        else:
            st.info("No curriculum subjects registered yet. Add one from the form.")

        st.markdown("</div>", unsafe_allow_html=True)

# ==============================================================================
# VIEW 4: MARKS ENTRY & VALIDATION (UPSERT)
# ==============================================================================
elif nav_selection == "Marks Entry":
    st.markdown("""
    <div class="edu-header-container">
        <div>
            <div class="edu-header-title">📝 Marks Entry & Record Ledger</div>
            <div class="edu-header-sub">Record, validate, and update individual subject examination marks</div>
        </div>
        <div class="edu-header-pill">Upsert & Validation Mode</div>
    </div>
    """, unsafe_allow_html=True)

    conn = get_db_connection()
    students_list = pd.read_sql_query("SELECT id, roll_number, name FROM students ORDER BY roll_number ASC;", conn)
    subjects_list = pd.read_sql_query("SELECT id, subject_name, maximum_marks FROM subjects ORDER BY subject_name ASC;", conn)
    conn.close()

    if students_list.empty or subjects_list.empty:
        st.warning("⚠️ Please ensure at least one Student and one Subject are registered before entering marks.")
    else:
        col_form, col_matrix = st.columns([1, 1.8])

        with col_form:
            st.markdown("""
            <div class="edu-card">
                <div class="edu-card-title">✏️ Enter / Update Marks</div>
                <div class="edu-card-subtitle">Select student and course to record or update verified score</div>
            """, unsafe_allow_html=True)

            student_options = {f"{r['roll_number']} - {r['name']}": r['id'] for _, r in students_list.iterrows()}
            selected_student_str = st.selectbox("Select Student *", options=list(student_options.keys()))
            selected_student_id = student_options[selected_student_str]

            subject_options = {f"{r['subject_name']} (Max: {r['maximum_marks']:.0f})": (r['id'], r['maximum_marks']) for _, r in subjects_list.iterrows()}
            selected_subject_str = st.selectbox("Select Subject *", options=list(subject_options.keys()))
            selected_subject_id, max_allowed_marks = subject_options[selected_subject_str]

            # Query existing marks if already entered
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT marks_obtained FROM marks WHERE student_id = ? AND subject_id = ?;", (selected_student_id, selected_subject_id))
            existing_row = cursor.fetchone()
            conn.close()

            existing_val = float(existing_row["marks_obtained"]) if existing_row else 0.0

            if existing_row:
                st.info(f"ℹ️ A mark of **{existing_val}** is currently recorded. Entering a new value will update this record.")

            # Input bounded by maximum marks
            input_marks = st.number_input(
                f"Marks Obtained (0.0 to {max_allowed_marks:.0f}) *",
                min_value=0.0,
                max_value=float(max_allowed_marks),
                value=existing_val if existing_row else 0.0,
                step=1.0,
                help=f"Must be between 0 and {max_allowed_marks:.0f}"
            )

            # Upsert button
            if st.button("💾 Save / Update Marks Record", type="primary", use_container_width=True):
                # Strict validation check
                if input_marks < 0.0 or input_marks > max_allowed_marks:
                    st.error(f"❌ Validation Error: Marks must be strictly between 0 and {max_allowed_marks:.0f}.")
                else:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    try:
                        cursor.execute("""
                        INSERT INTO marks (student_id, subject_id, marks_obtained)
                        VALUES (?, ?, ?)
                        ON CONFLICT(student_id, subject_id)
                        DO UPDATE SET marks_obtained = excluded.marks_obtained;
                        """, (selected_student_id, selected_subject_id, float(input_marks)))
                        conn.commit()
                        st.success(f"✅ Marks recorded successfully! ({input_marks:.1f} / {max_allowed_marks:.0f})")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Database error: {str(e)}")
                    finally:
                        conn.close()

            st.markdown("</div>", unsafe_allow_html=True)

        with col_matrix:
            # Pivot table showing marks obtained per student and subject
            conn = get_db_connection()
            query = """
            SELECT s.roll_number, s.name, sub.subject_name, m.marks_obtained
            FROM students s
            CROSS JOIN subjects sub
            LEFT JOIN marks m ON s.id = m.student_id AND sub.id = m.subject_id
            ORDER BY s.roll_number ASC, sub.subject_name ASC;
            """
            ledger_df = pd.read_sql_query(query, conn)
            conn.close()

            if not ledger_df.empty:
                pivot = ledger_df.pivot(index=["roll_number", "name"], columns="subject_name", values="marks_obtained")
                pivot_reset = pivot.reset_index()

                # Build clean HTML table
                cols = [c for c in pivot_reset.columns if c not in ["roll_number", "name"]]
                html = """
                <div class="edu-card">
                    <div class="edu-card-title">📑 Comprehensive Evaluation Ledger</div>
                    <div class="edu-card-subtitle">Grid matrix of all entered scores with real-time pending flags</div>
                    <div style="overflow-x: auto;">
                    <table class="edu-table">
                        <thead>
                            <tr>
                                <th>Roll No</th>
                                <th>Student Name</th>
                """
                for c in cols:
                    html += f"<th>{c}</th>"
                html += """
                            </tr>
                        </thead>
                        <tbody>
                """

                for _, row in pivot_reset.iterrows():
                    html += f"<tr><td><strong>{row['roll_number']}</strong></td><td>{row['name']}</td>"
                    for c in cols:
                        val = row[c]
                        if pd.isna(val):
                            html += '<td><span class="badge-pill badge-status-pending">Pending</span></td>'
                        else:
                            html += f"<td><strong>{val:.0f}</strong></td>"
                    html += "</tr>"

                html += """
                        </tbody>
                    </table>
                    </div>
                </div>
                """
                render_clean_html(html)
            else:
                st.info("Ledger will display as soon as students and subjects are available.")

# ==============================================================================
# VIEW 5: DIGITAL REPORT CARDS
# ==============================================================================
elif nav_selection == "Reports":
    st.markdown("""
    <div class="edu-header-container">
        <div>
            <div class="edu-header-title">📄 Digital Report Card Generation</div>
            <div class="edu-header-sub">Standardized institutional marksheets with automated evaluation & digital export</div>
        </div>
        <div class="edu-header-pill">MITS Official Format</div>
    </div>
    """, unsafe_allow_html=True)

    if results_df.empty:
        st.warning("⚠️ No student records found. Add students first.")
    else:
        student_selector_map = {f"{r['roll_number']} - {r['name']}": r['id'] for _, r in results_df.iterrows()}
        selected_rep_label = st.selectbox("Select Candidate to Generate Report Card:", options=list(student_selector_map.keys()))
        selected_rep_id = student_selector_map[selected_rep_label]

        # Fetch student and subject-wise details
        s_data = results_df[results_df["id"] == selected_rep_id].iloc[0]

        conn = get_db_connection()
        rep_query = """
        SELECT sub.subject_name, sub.maximum_marks, m.marks_obtained
        FROM subjects sub
        LEFT JOIN marks m ON sub.id = m.subject_id AND m.student_id = ?
        ORDER BY sub.id ASC;
        """
        rep_marks_df = pd.read_sql_query(rep_query, conn, params=(selected_rep_id,))
        conn.close()

        # Check completeness
        has_pending = rep_marks_df["marks_obtained"].isna().any()

        # Build formal institutional report card view
        card_html = f"""
        <div class="report-card-sheet">
            <div class="report-header-inst">
                <h2>MADHAV INSTITUTE OF TECHNOLOGY & SCIENCE (MITS), GWALIOR</h2>
                <h4>(A Govt. Aided UGC Autonomous & NAAC Accredited Institute, Affiliated to RGPV, Bhopal)</h4>
                <div class="badge-doc">OFFICIAL DIGITAL ACADEMIC REPORT CARD</div>
            </div>

            <div class="report-meta-grid">
                <div>
                    <div class="report-meta-row"><strong>Candidate Name:</strong> {s_data['name']}</div>
                    <div class="report-meta-row"><strong>Roll Number:</strong> {s_data['roll_number']}</div>
                    <div class="report-meta-row"><strong>Department / Branch:</strong> {s_data['class_name']}</div>
                </div>
                <div>
                    <div class="report-meta-row"><strong>Semester:</strong> {s_data['semester']}</div>
                    <div class="report-meta-row"><strong>Academic Session:</strong> {s_data['academic_year']}</div>
                    <div class="report-meta-row"><strong>Issue Date:</strong> {datetime.now().strftime("%d %B %Y")}</div>
                </div>
            </div>
        """

        if has_pending:
            card_html += """
            <div style="background:#FFFBEB; border:1px solid #FCD34D; border-radius:8px; padding:12px 16px; margin-bottom:16px; font-size:13px; color:#92400E;">
                ⚠️ <strong>Notice:</strong> This student's evaluation is incomplete. Missing subject marks are pending. Final grade and pass/fail standing will be officially declared once all evaluations are entered.
            </div>
            """

        card_html += """
        <table class="edu-table" style="margin-top: 10px;">
            <thead>
                <tr>
                    <th>Subject Code & Title</th>
                    <th style="text-align:center;">Maximum Marks</th>
                    <th style="text-align:center;">Marks Obtained</th>
                    <th style="text-align:center;">Percentage</th>
                    <th style="text-align:center;">Subject Grade</th>
                    <th style="text-align:center;">Result Status</th>
                </tr>
            </thead>
            <tbody>
        """

        for _, m_row in rep_marks_df.iterrows():
            sub_name = m_row["subject_name"]
            max_m = m_row["maximum_marks"]
            obt_m = m_row["marks_obtained"]

            if pd.isna(obt_m):
                obt_str = "Pending"
                pct_str = "-"
                g_str = '<span class="badge-pill badge-status-pending">Pending</span>'
                res_str = '<span class="badge-pill badge-status-pending">Awaited</span>'
            else:
                obt_str = f"{obt_m:.1f}"
                pct_val = (obt_m / max_m) * 100.0
                pct_str = f"{pct_val:.1f}%"
                sub_grade = calculate_grade(pct_val)
                g_str = get_grade_badge_html(sub_grade)
                sub_res = "Pass" if pct_val >= 40.0 else "Fail"
                res_str = get_status_badge_html(sub_res)

            card_html += f"""
                <tr>
                    <td><strong>{sub_name}</strong></td>
                    <td style="text-align:center;">{max_m:.0f}</td>
                    <td style="text-align:center;">{obt_str}</td>
                    <td style="text-align:center;">{pct_str}</td>
                    <td style="text-align:center;">{g_str}</td>
                    <td style="text-align:center;">{res_str}</td>
                </tr>
            """

        card_html += "</tbody></table>"

        # Summary box
        if not has_pending:
            card_html += f"""
            <div class="report-summary-box">
                <div>
                    <div style="font-size:12px; font-weight:700; color:#64748B; text-transform:uppercase;">Grand Total Aggregate</div>
                    <div style="font-size:24px; font-weight:800; color:#0F172A;">{s_data['total_marks']:.0f} / {s_data['max_marks']:.0f}</div>
                    <div style="font-size:13px; color:#475569; margin-top:2px;">Overall Percentage: <strong>{s_data['percentage']:.2f}%</strong></div>
                </div>
                <div style="text-align:center;">
                    <div style="font-size:12px; font-weight:700; color:#64748B; text-transform:uppercase; margin-bottom:4px;">Awarded Grade</div>
                    <div style="font-size:20px;">{get_grade_badge_html(s_data['grade'])}</div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:12px; font-weight:700; color:#64748B; text-transform:uppercase; margin-bottom:4px;">Final Academic Result</div>
                    <div style="font-size:20px;">{get_status_badge_html(s_data['status'])}</div>
                </div>
            </div>
            """
        else:
            card_html += f"""
            <div class="report-summary-box" style="border-color:#FCD34D; background:#FFFBEB;">
                <div>
                    <div style="font-size:12px; font-weight:700; color:#B45309; text-transform:uppercase;">Evaluation Status</div>
                    <div style="font-size:20px; font-weight:800; color:#92400E;">Pending Marks Entry</div>
                    <div style="font-size:13px; color:#78350F; margin-top:2px;">Entered Marks Sum: <strong>{s_data['total_marks']:.0f} / {s_data['max_marks']:.0f}</strong></div>
                </div>
                <div style="text-align:right;">
                    <span class="badge-pill badge-status-pending" style="font-size:14px; padding:6px 16px;">PENDING FINALIZATION</span>
                </div>
            </div>
            """

        card_html += """
            <div style="margin-top:28px; display:flex; justify-content:space-between; align-items:flex-end; font-size:11.5px; color:#64748B; border-top:1px dashed #CBD5E1; padding-top:16px;">
                <div>
                    Digitally generated via <strong>EduAnalytics Portal</strong><br>
                    Verification Hash: <em>MITS-EDU-VERIFIED-2026-OK</em>
                </div>
                <div style="text-align:center;">
                    <div style="width:140px; border-bottom:1px solid #94A3B8; margin-bottom:4px;"></div>
                    Controller of Examinations
                </div>
            </div>
        </div>
        """

        render_clean_html(card_html)

        # DOWNLOAD DIGITAL REPORT CARD (.TXT)
        # Construct clean ASCII document
        sep = "=" * 70
        sub_sep = "-" * 70

        txt_report = f"""{sep}
MADHAV INSTITUTE OF TECHNOLOGY & SCIENCE (MITS), GWALIOR
(A Govt. Aided UGC Autonomous & NAAC Accredited Institute, Affiliated to RGPV)
OFFICIAL DIGITAL ACADEMIC REPORT CARD
{sep}

CANDIDATE INFORMATION:
  Roll Number      : {s_data['roll_number']}
  Candidate Name   : {s_data['name']}
  Branch / Class   : {s_data['class_name']}
  Semester         : {s_data['semester']}
  Academic Session : {s_data['academic_year']}
  Date of Issue    : {datetime.now().strftime("%d-%b-%Y")}

{sub_sep}
ACADEMIC COURSE EVALUATION:
{sub_sep}
{"Subject Name":<25} {"Max Marks":<12} {"Obtained":<12} {"Percentage":<12} {"Grade":<8}
{sub_sep}
"""
        for _, m_row in rep_marks_df.iterrows():
            sub_name = m_row["subject_name"]
            max_m = m_row["maximum_marks"]
            obt_m = m_row["marks_obtained"]
            if pd.isna(obt_m):
                txt_report += f"{sub_name:<25} {max_m:<12.0f} {'Pending':<12} {'-':<12} {'Pending':<8}\n"
            else:
                pct = (obt_m / max_m) * 100.0
                g = calculate_grade(pct)
                txt_report += f"{sub_name:<25} {max_m:<12.0f} {obt_m:<12.1f} {pct:<11.1f}% {g:<8}\n"

        txt_report += f"""{sub_sep}
PERFORMANCE SUMMARY:
  Total Marks Obtained : {s_data['total_marks']:.0f} / {s_data['max_marks']:.0f}
  Overall Percentage   : {s_data['percentage']:.2f}%
  Final Awarded Grade  : {s_data['grade']}
  Academic Result      : {s_data['status']}
{sep}
AUTHENTICATION:
  Digitally Generated by EduAnalytics Academic Engine
  Institute: MITS Gwalior (Session 2026-27)
  Verified & Approved by: Controller of Examinations
{sep}
"""
        col_dl, _ = st.columns([1, 2])
        with col_dl:
            st.download_button(
                label="📥 Download Digital Report Card (.txt)",
                data=txt_report,
                file_name=f"Report_Card_{s_data['roll_number']}_{datetime.now().strftime('%Y%m%d')}.txt",
                mime="text/plain",
                type="primary",
                use_container_width=True
            )

# ==============================================================================
# VIEW 6: ANALYTICS & INSTITUTIONAL GRADING CRITERIA
# ==============================================================================
elif nav_selection == "Analytics":
    st.markdown("""
    <div class="edu-header-container">
        <div>
            <div class="edu-header-title">📈 Academic Performance Analytics</div>
            <div class="edu-header-sub">Statistical distributions, subject-wise diagnostics, and institutional grading standards</div>
        </div>
        <div class="edu-header-pill">Institutional Analytics</div>
    </div>
    """, unsafe_allow_html=True)

    col_stat_table, col_criteria = st.columns([1.6, 1.4])

    with col_stat_table:
        if not subjects_df.empty and not raw_marks_df.empty:
            stats_list = []
            for _, s_row in subjects_df.iterrows():
                sub_id = s_row["id"]
                sub_name = s_row["subject_name"]
                sub_max = s_row["maximum_marks"]
                sub_marks = raw_marks_df[raw_marks_df["subject_id"] == sub_id]["marks_obtained"]

                if not sub_marks.empty:
                    eval_count = len(sub_marks)
                    avg_m = sub_marks.mean()
                    high_m = sub_marks.max()
                    low_m = sub_marks.min()
                    pass_c = (sub_marks >= (0.40 * sub_max)).sum()
                    subj_pass_rate = (pass_c / eval_count) * 100.0
                else:
                    eval_count = 0
                    avg_m = 0.0
                    high_m = 0.0
                    low_m = 0.0
                    pass_c = 0
                    subj_pass_rate = 0.0

                stats_list.append({
                    "Subject": sub_name,
                    "Max Marks": int(sub_max),
                    "Evaluated": eval_count,
                    "Average Marks": f"{avg_m:.1f}",
                    "Highest": f"{high_m:.1f}",
                    "Lowest": f"{low_m:.1f}",
                    "Pass Rate": f"{subj_pass_rate:.1f}%"
                })

            stats_df = pd.DataFrame(stats_list)

            # Styled HTML Table
            stat_html = """
            <div class="edu-card">
                <div class="edu-card-title">📊 Subject-Wise Statistical Summary</div>
                <div class="edu-card-subtitle">Detailed evaluation metrics across all registered courses</div>
                <div style="overflow-x:auto;">
                <table class="edu-table">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Max</th>
                            <th>Evaluated</th>
                            <th>Average</th>
                            <th>Highest</th>
                            <th>Lowest</th>
                            <th>Pass Rate</th>
                        </tr>
                    </thead>
                    <tbody>
            """
            for _, r in stats_df.iterrows():
                stat_html += f"""
                        <tr>
                            <td><strong>{r['Subject']}</strong></td>
                            <td>{r['Max Marks']}</td>
                            <td>{r['Evaluated']}</td>
                            <td><strong>{r['Average Marks']}</strong></td>
                            <td><span style="color:#10B981; font-weight:700;">{r['Highest']}</span></td>
                            <td><span style="color:#EF4444; font-weight:700;">{r['Lowest']}</span></td>
                            <td><span class="badge-pill badge-status-pass">{r['Pass Rate']}</span></td>
                        </tr>
                """
            stat_html += """
                    </tbody>
                </table>
                </div>
            </div>
            """
            render_clean_html(stat_html)
        else:
            st.info("Statistical data will appear once marks are recorded.")

    with col_criteria:
        grading_bands = [
            ("90% and above", "AAA", "Outstanding", "badge-grade-aaa"),
            ("80% – 89.99%", "AA",  "Excellent",   "badge-grade-aa"),
            ("70% – 79.99%", "A",   "Very Good",   "badge-grade-a"),
            ("60% – 69.99%", "B",   "Good",        "badge-grade-b"),
            ("50% – 59.99%", "C",   "Fair",        "badge-grade-c"),
            ("40% – 49.99%", "D",   "Pass",        "badge-grade-d"),
            ("Below 40%",    "F",   "Fail",        "badge-grade-f"),
        ]

        crit_html = """
        <div class="edu-card">
            <div class="edu-card-title">🎖️ Institutional Grading Criteria</div>
            <div class="edu-card-subtitle">Official grading bands and performance classifications</div>
            <div style="overflow-x:auto;">
            <table class="edu-table">
                <thead>
                    <tr>
                        <th>Percentage Range</th>
                        <th>Grade</th>
                        <th>Classification</th>
                        <th>Badge</th>
                    </tr>
                </thead>
                <tbody>
        """
        for r_range, g_code, desc, cls_name in grading_bands:
            crit_html += f"""
                    <tr>
                        <td><strong>{r_range}</strong></td>
                        <td><strong>{g_code}</strong></td>
                        <td>{desc}</td>
                        <td><span class="badge-pill {cls_name}">{g_code}</span></td>
                    </tr>
            """
        crit_html += """
                </tbody>
            </table>
            </div>
        </div>
        """
        render_clean_html(crit_html)

    # Comparative Visualization: Highest vs Lowest vs Average
    if not subjects_df.empty and not raw_marks_df.empty:
        st.markdown("""
        <div class="edu-card">
            <div class="edu-card-title">📊 Subject Score Diagnostics (Highest vs Average vs Lowest)</div>
            <div class="edu-card-subtitle">Comprehensive score spread comparison per academic course</div>
        """, unsafe_allow_html=True)

        comp_subjects = []
        comp_high = []
        comp_avg = []
        comp_low = []

        for _, s_row in subjects_df.iterrows():
            sub_id = s_row["id"]
            sub_name = s_row["subject_name"]
            sub_marks = raw_marks_df[raw_marks_df["subject_id"] == sub_id]["marks_obtained"]
            comp_subjects.append(sub_name)
            if not sub_marks.empty:
                comp_high.append(round(sub_marks.max(), 1))
                comp_avg.append(round(sub_marks.mean(), 1))
                comp_low.append(round(sub_marks.min(), 1))
            else:
                comp_high.append(0)
                comp_avg.append(0)
                comp_low.append(0)

        fig_diag = go.Figure(data=[
            go.Bar(name='Highest Score', x=comp_subjects, y=comp_high, marker_color='#10B981'),
            go.Bar(name='Average Score', x=comp_subjects, y=comp_avg, marker_color='#3B82F6'),
            go.Bar(name='Lowest Score', x=comp_subjects, y=comp_low, marker_color='#EF4444'),
        ])

        fig_diag.update_layout(
            barmode='group',
            yaxis=dict(
                title=dict(text="Marks", font=dict(size=13, color="#475569")),
                gridcolor="#F1F5F9",
                tickfont=dict(size=12, color="#64748B")
            ),
            xaxis=dict(
                tickfont=dict(size=12, color="#334155")
            ),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
            margin=dict(l=20, r=20, t=30, b=20),
            height=340
        )

        st.plotly_chart(fig_diag, use_container_width=True, config={"displayModeBar": False})
        st.markdown("</div>", unsafe_allow_html=True)
