# EduAnalytics - Academic Performance & Digital Report Card System

An automated educational analytics platform built with Python, Streamlit, SQLite, Pandas, and Plotly.

## 🚀 How to Open and Run

### Option 1: Quick Launch (HTML Link / Shortcut)
- **HTML Launcher**: Open `open_app.html` in any web browser. It will immediately redirect you to `http://localhost:8501`.
- **Windows Shortcut**: Double-click `EduAnalytics.url` to open `http://localhost:8501` in your default browser.

*(Note: The Streamlit server must be running on your machine for the localhost link to respond).*

---

### Option 2: Start the Application Server
If the server isn't running yet:

1. **One-Click Run (Windows)**:
   Double-click `run.bat` in this folder. It will install required dependencies and automatically launch the app in your browser at `http://localhost:8501`.

2. **Manual Run (Command Prompt / PowerShell / Terminal)**:
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```

---

## 📁 Package Contents
- `app.py`: Main Streamlit application codebase.
- `eduanalytics.db`: SQLite database containing sample student and exam data.
- `requirements.txt`: Python package dependencies.
- `open_app.html`: HTML link file to launch `http://localhost:8501`.
- `EduAnalytics.url`: Direct Windows internet shortcut.
- `run.bat`: One-click startup script.
- `.streamlit/config.toml`: Application theme and server configuration.
